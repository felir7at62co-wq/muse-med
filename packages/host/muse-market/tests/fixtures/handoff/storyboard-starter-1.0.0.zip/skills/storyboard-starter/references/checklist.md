Check scene order, character continuity, and missing inputs. Do not invent facts.
