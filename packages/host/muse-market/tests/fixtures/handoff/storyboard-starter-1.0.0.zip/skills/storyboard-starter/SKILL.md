---
name: storyboard-starter
description: Review supplied storyboard scenes.
---
Read the supplied scenes. Ask for missing context and list continuity issues. Read references/checklist.md only when a checklist is useful.
