---
name: storyboard-review
description: Review supplied storyboard scenes for continuity.
---
Review only the supplied scene descriptions. Identify missing information and continuity issues.
